import pickle
import os
import tkinter
from tkinter import *
from os import name, path
import time,random,smtplib

import test





#--------------------------------------------------------------------------------------------------------------------------------------------

        #GUI FOR SIGNUP PAGE
root=Tk()
root.title("Signup Page")
root.geometry("1280x720")
root.resizable(False,False)
#bf=PhotoImage(file="G:\\bg.png")
#my=Label(root,image=bf)
#my.place(x=0,y=0,relwidth=1,relheight=1)
root.config(bg="#191919")

#e=Entry(root,width=50)
#we use e.get to get entry from entry box
#e.pack()

class main:
    
    def __init__(self,master):
        #defining image
        
        global S
        logframe=Frame(master,bg="#191919",height=450,width=400)
        logframe.place(x=450,y=220)



        ''' ------------------------------- SIGN UP PAGE----------------------------------'''

        def OTP(email):
            f=random.randint(1000,9999)
            
            s = smtplib.SMTP('smtp.gmail.com', 587)
            
            s.starttls()
            

            s.login("otp.validate@gmail.com", "Microsoft@10")
            

            message = f'{f}'
            
            print(message)

            try:
                s.sendmail("otp.validate@gmail.com", f'{email}', message)
            except:
                print("Wromg email")
            
            s.quit()
            return message




        def signup():

        #-------------------------- DESTROYING LOGIN WIDGETS----------------------------------
            for widgets in logframe.winfo_children():
                widgets.destroy()

        # NAME AND ENTRY BOX OF NAME   
            Name=Label(logframe,text="N A M E : ",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
            Name.place(x=70,y=20)
            Nameentry=Entry(logframe,width=30,bg="#343434",relief="flat",fg="white")
            Nameentry.place(x=150,y=20,height=20)


            # PASSWORD AND ENTRY BOX OF PASSWORD
            PAS=Label(logframe,text="P A S S W O R D : ",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
            PAS.place(x=15,y=70)
            passwordentry=Entry(logframe,width=30,bg="#343434",relief="flat",fg="white")
            passwordentry.place(x=150,y=70,height=20)

            # EMAIL AND ENTRY BOX OF EMAIL
            EMA=Label(logframe,text="E - M A I L : ",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
            EMA.place(x=50,y=120)
            EMAILENTRY=Entry(logframe,width=30,bg="#343434",relief="flat",fg="white")
            EMAILENTRY.place(x=150,y=120,height=20)

            #GET DATA FROM ENTRY BOX ON CLICKING SUBMIT BUTTON AND STORE INFO IN FILE
            
            # FUNCTION TO CHECK IF USER DATA IS ALREADY AVAILABLE OR NOT
            def already_registered(email):
                #SEARCH FOR THE NAME OF FILE WITH USERNAME

                listing=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\Data")
                for root_path,directiories, files in listing:
                    full_file_name=email+".dat"
                    if full_file_name in files:
                        
                        #If name is found then it will return false
                        return True
                    else:
                        return False
            
            
            def get_data():
                
                usr=Nameentry.get()
                pas=passwordentry.get()
                em=EMAILENTRY.get()
                global data
                data=[usr,pas,em]
                flag_user=already_registered(em)
                
                if(usr)=="" or (pas)=="" or (em)=="" :
                    succes=Label(text="E N T E R  V A L I D  D A T A",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                    succes.place(x=550,y=400)
                    def destry():
                            succes.destroy()
                    root.after(1500,destry)
                elif (flag_user==True):
                    succes=Label(text="E M A I L  I S  A L R E A D Y  R E G I S T E R E D",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                    succes.place(x=550,y=400)
                    def destry():
                            succes.destroy()
                    root.after(1500,destry)
                

                else:
                    # IF ALL THE ENTRY FIELDS ARE FILLED THEN
                    #destroying old widgets
                    for widgets in logframe.winfo_children():
                        widgets.destroy()
                    # SHOWING OTP LABEL AND ENTRY FRAME

                    sendotp=OTP(em)
                    otp=Label(logframe,text="  O T P : ",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                    otp.place(x=50,y=170)
                    otp1=Entry(logframe,width=30,bg="#343434",relief="flat",fg="white")
                    otp1.place(x=150,y=170,height=20)
                    
                    def validate1():
                        print("I take the text from entry widget")
                        checkuser=otp1.get()
                        print("i am checking sentotp and checkuser")
                        if sendotp==checkuser:
                            store_name=f'{em}'
                            pickle.dump(data,open(f'C:\\Users\Sanjay-pc\Desktop\College Mini Project\Data\{store_name}.dat',"wb"))
                            succes=Label(text="S U C C E S S F U L L Y   R E G I S T E R E D",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                            succes.place(x=530,y=350)
                            def destry():
                                succes.destroy()
                            root.after(1500,destry)
                            S="SAurabh"
                        else:
                            succes=Label(text="E N T E R   C O R R E C T   E M A I L - I D",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                            succes.place(x=530,y=350)
                            def destry():
                                succes.destroy()
                            root.after(1500,destry)
                    VAL=Button(logframe,text="VA L I D A T E",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"),command=validate1)
                    VAL.place(x=150,y=200)


            submitbtn=Button(logframe,text="S U B M I T",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"),command=get_data)
            submitbtn.place(x=150,y=250)

                
            
      
            
            
        '''-------------------------------------- LOGIN PAGE---------------------------------------------'''
        def login():
            
            #DESTROYING SIGNUP WIDGETS
            
            for widgets in logframe.winfo_children():
                widgets.destroy()
            
            # NAME AND ENTRY BOX OF NAME   
            lName=Label(logframe,text="E M A I L : ",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
            lName.place(x=70,y=20)
            lNameentry=Entry(logframe,width=30,bg="#343434",relief="flat",fg="white")
            lNameentry.place(x=150,y=20,height=20)


            # PASSWORD AND ENTRY BOX OF PASSWORD
            lPAS=Label(logframe,text="P A S S W O R D : ",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
            lPAS.place(x=15,y=70)
            lpasswordentry=Entry(logframe,width=30,bg="#343434",relief="flat",fg="white")
            lpasswordentry.place(x=150,y=70,height=20)
            
            
            def validate():
                #log.remove('yes')
                
                name=lNameentry.get()
                password=lpasswordentry.get()
                #This will search for username file in the folder
                listing=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\Data")
                for root_path,directiories, files in listing:
                    full_file_name=name+".dat"
                    if full_file_name in files:
                        
                        #If name is found then it will open file for password
                        data_list=pickle.load(open(f'C:\\Users\Sanjay-pc\Desktop\College Mini Project\Data\{name}.dat',"rb"))
                        if data_list[1]==password:
                            # data_list[2] contains email
                            succes=Label(text="L O G I N  S U C C E S S F U L L",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                            succes.place(x=530,y=350)
                            def destry():
                                succes.destroy()
                            root.after(1500,destry)
                            for widgets in root.winfo_children():
                                widgets.destroy()
                            try:
                                obj=test.main1(root,data_list[2],frame_bg="#161616",label_fg="white",frame_bg1="#222222")
                                #root=Tk()
                                
                            except:
                                print("error")
                            
                            
                            
                            
                            
                        else:
                            succes=Label(text="E N T E R   C O R R E C T   P A S S W O R D",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                            succes.place(x=530,y=350)
                            def destry():
                                succes.destroy()
                            root.after(1500,destry)
                            
                    else:
                        succes=Label(text="N O  U S E R   D A T A  F O U N D",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"))
                        succes.place(x=530,y=350)
                        def destry():
                                succes.destroy()
                        root.after(1500,destry)
            validatebtn=Button(logframe,text="L O G I N",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"),command=validate)
            validatebtn.place(x=150,y=200)
        
        signup()
        signupbutton=Button(root,text="S I G N - U P ",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"),command=signup)
        signupbutton.place(x=680,y=150)

        loginbtn=Button(root,text="L O G I N",relief='flat',bg="#191919",fg="white",font=("FZYaoTi"),command=login)
        loginbtn.place(x=520,y=150)
        
        
        
        #----------------------------------------- ENF

e=main(root)
root.mainloop()


