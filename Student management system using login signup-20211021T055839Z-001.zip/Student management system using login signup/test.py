
import pickle
import os
import tkinter
from tkinter import *
from os import path, stat
import time,random,smtplib
import threading
from tkinter import ttk
from tkinter import messagebox
from tkinter.font import families

#--------------------------------------------------------------------------------------------------------------------------------------------

#list to store and update student info in the students section in manage tab
# If you are running this program in any other system, this program works on local files.
# So make sure to create folders with the name of students,employees,department,course and provide location to respective files to below variables.


path_students="C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\students"
path_employees="C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\employees"
path_dept="C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\departments"
path_course="C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\course"

del_course=[]

# ALGORITHM TO CHECK IF ANY COURSES ARE AVAILABLE OR NOT ... IF AVAILABLE THEN DEPARTMENTS ARE AVAILALE OR NOT.... IF YES THEN WE CAN ADD STUDENTS




#root=Tk()
#root.title("Signup Page")
#root.geometry("1280x720")
#root.resizable(False,False)
#bf=PhotoImage(file="G:\\bg.png")
#my=Label(root,image=bf)
#my.place(x=0,y=0,relwidth=1,relheight=1)

        #GUI FOR SIGNUP PAGE
class main1:
        def __init__(self,master,username,frame_bg,label_fg,frame_bg1):
        
        #------------------------------ GUI FOR LANDING PAGE---------------------------
                topframe=Frame(master,bg=frame_bg)
                topframe.place(x=0,y=0,height=90,width=1280)

                sideframe=Frame(master,bg=frame_bg)
                sideframe.place(x=0,y=90,height=650,width=120)


                dispframe=Frame(master,bg=frame_bg1)
                dispframe.place(x=119,y=90,height=710,width=1160)


                welcome=Label(topframe,text="W E L C O M E",font=("FZYaoTi",20),fg=label_fg,bg=frame_bg)
                welcome.place(x=580,y=30)

                user_email=Label(topframe,text=f'{username}',font=("calibri",10),fg=label_fg,bg=frame_bg)
                user_email.place(x=1095,y=15)


                logoutbtn=Button(topframe,text="L o g o u t",font=("FZYaoTi"),fg=label_fg,bg=frame_bg,relief="flat")
                logoutbtn.place(x=1130,y=40)


                #home_page=Label(dispframe,text="T H I S   I S   H O M E   P A G E ",font=("FZYaoTi"),fg=label_fg,bg=frame_bg1,relief="flat")
                #home_page.place(x=100,y=70)



                def home():
                        # GIVES NUMBER OF STUDENTS
                        for widgets in dispframe.winfo_children():
                                widgets.destroy()
                        def stu_count():
                                stu_path=os.walk(f'{path_students}')
                                root_path,directiories,files = next(stu_path)      

                                

                                total_students=Label(dispframe,text=f'T O T A L \t {len(files)} \t S T U D E N T S',bg=frame_bg,relief="flat",fg=label_fg)
                                total_students.place(x=100,y=70,height=200,width=400)
                        
                        def emp_count():
                                stu_path=os.walk(f'{path_employees}')
                                root_path,directiories,files = next(stu_path)      
                                total_students=Label(dispframe,text=f'T O T A L \t {len(files)} \t E M P L O  Y E E S',bg=frame_bg,relief="flat",fg=label_fg)
                                total_students.place(x=650,y=70,height=200,width=400)

                        def dep_count():
                                stu_path=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\departments")
                                root_path,directiories,files = next(stu_path)      
                                total_students=Label(dispframe,text=f'T O T A L \t {len(files)} \t D E P A R T M E N T',bg=frame_bg,relief="flat",fg=label_fg)
                                total_students.place(x=100,y=350,height=200,width=400)

                        # WRITE A FUNCTION TO SHOW CURRENT USER DETAILS
                        
                        stu_count()
                        emp_count()
                        dep_count()


                #------------------------- FUNCTION FOR MANAGE TAB--------------------------
                # Students tab under manage
                def student_m():
                        stu_path=os.walk(f'{path_course}')
                        stu_path1=os.walk(f'{path_dept}')
                        stu_path_stu=os.walk(f'{path_students}')
                        root_path,directiories,files = next(stu_path)
                        root_path1,directiories1,files1 = next(stu_path1)
                        root_path3,directiories3,files3 = next(stu_path_stu)
                        Course_Names=[]
                        for item in files:
                                
                                Course_Names.append(item.replace('.dat',''))
                        # Now we will open every file and check if thew course name is there or not... if not then delete
                        for j in files3:
                                
                                open_s=pickle.load(open(f'{path_students}\{j}',"rb"))
                                
                                if open_s[5] not  in Course_Names:
                                        os.remove(f'{path_students}\{j}')
                                else:
                                        pass
                               

                        
                

                        if len(files)==0:
                                x="no_course"
                        
                        else:
                                if len(files1)==0:
                                        x="no_dept"
                                else:
                                        x="yes"

                        


                        student_manage_frame=Frame(dispframe,bg=frame_bg)
                        student_manage_frame.place(x=0,y=0,height=650,width=220)

                        student_manage_disp=Frame(dispframe,bg=frame_bg1)
                        student_manage_disp.place(x=220,y=0,height=650,width=940)

                        

                        my_student=ttk.Treeview(student_manage_disp )
                        s=ttk.Style()
                        #pick a theme
                        s.theme_use("clam")
                        # configure treeview colourd
                        s.configure('Treeview',rowheight=60,
                        background=frame_bg1,
                        foreground="white",
                        fieldbackground=frame_bg1                  
                        
                        )

                        s.configure('Treeview.Heading', background=frame_bg, foreground='white',relief="flat")

                        s.map('Treeview',background=[('selected','green')],foreground=[('selected','grey')])

                        def student_info_m():
                                        
                                        #define columns
                                        my_student['columns']=("id","Name","rollno","registration","email","dept","course")
                                        #formate our columns
                                        my_student.column("#0",width=0,stretch=NO)
                                        my_student.column("id",anchor=W,width=30)
                                        my_student.column("Name",anchor=W,width=200)
                                        my_student.column("rollno",anchor=CENTER,width=150)
                                        my_student.column("registration",anchor=W,width=150)
                                        my_student.column("email",anchor=W,width=150)
                                        my_student.column("dept",anchor=W,width=150)
                                        my_student.column("course",anchor=W,width=150)

                                        #Create Heading
                                        my_student.heading("#0",text="",anchor=W)
                                        my_student.heading("id",text="ID",anchor=W)
                                        my_student.heading("Name",text="Student Name",anchor=W)
                                        my_student.heading("rollno",text="Roll No",anchor=W)
                                        my_student.heading("registration",text="Registration",anchor=W)
                                        my_student.heading("email",text="E-Mail",anchor=W)
                                        my_student.heading("dept",text="Department",anchor=W)
                                        my_student.heading("course",text="Course",anchor=W)
                                        my_student.pack()

                                        #Opening files of data to show in table
                                        listing=os.walk(path_students)
                                        for root_path,directiories, files in listing:
                                                #If name is found then it will open file for password
                                                count=1
                                                for file in files:
                                                        
                                                        data_list=pickle.load(open(f'{path_students}\{file}',"rb"))
                                                        print(data_list)
                                                        my_student.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[1],data_list[2],data_list[3],data_list[4],data_list[5]))
                                                        count+=1
                                                        

                        # This will show info upon clicking students tab under manage
                        
                        student_info_m()
                        # below function will add students data in the files
                        def add_student():
                                dept_names=set([])
                                if x=="no_course":
                                        messagebox.showinfo("No Course","You cannot add students because there are no courses available")
                                elif x=="no_dept":
                                        messagebox.showinfo("No Dept","You cannot add students because there are no departments available")
                                else:
                                 
                                        for widgets in student_manage_disp.winfo_children():
                                                widgets.destroy()
                                        # This will store info in the format [id,name,roll number,registration number,email] in the path
                                        manage_students_add_list=[]


                                        # We are here because courses are available it will prompt to selecr courses

                                        def select_course(): # Page 1 to add students
                                                
                                                for widgets in student_manage_disp.winfo_children():
                                                                widgets.destroy()
                                                clicked=StringVar()
                                                clicked.set(" Select Course ")
                                                length=len(clicked.get())
                                                 
                                                drop=OptionMenu(student_manage_disp,clicked,*Course_Names)
                                                drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                                drop["highlightthickness"]=0
                                                
                                                drop.place(x=400,y=250,height=21)
                                                

                                                
                                                full_namel=Label(student_manage_disp,text="S E L E C T  N A M E  O F  C O U R S E  Y O U  W A N T  T O  A D D   S T U D E N T   T O",bg=frame_bg1,fg=label_fg)
                                                full_namel.place(x=250,y=150,height=20)

                                                BACK=Button(student_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=student_m)
                                                BACK.place(x=800,y=50)

                                                def submit_course_name():
                                                        Course=clicked.get()
                                                        for widgets in student_manage_disp.winfo_children():
                                                                widgets.destroy()

                                                        full_name=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        full_name.place(x=250,y=100,height=20)
                                                        full_namel=Label(student_manage_disp,text="F U L L   N A M E",bg=frame_bg1,fg=label_fg)
                                                        full_namel.place(x=20,y=100,height=20)

                                                        roll=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        roll.place(x=250,y=150,height=20)
                                                        roll_l=Label(student_manage_disp,text="R O L L   N U M B E R",bg=frame_bg1,fg=label_fg)
                                                        roll_l.place(x=20,y=150,height=20)

                                                        registration_no=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        registration_no.place(x=250,y=200,height=20)
                                                        registration_nol=Label(student_manage_disp,text="R E G I S T R A T I O N   N U M B E R",bg=frame_bg1,fg=label_fg)
                                                        registration_nol.place(x=20,y=200,height=20)

                                                        e_mail=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        e_mail.place(x=250,y=250,height=20)
                                                        e_maill=Label(student_manage_disp,text="E - M A I L ",bg=frame_bg1,fg=label_fg)
                                                        e_maill.place(x=20,y=250,height=20)

                                                        departments=os.walk(path_dept)
                                                        root_dept,directiories_dept,files_dept=next(departments)
                                                        
                                                        for names in files_dept:
                                                                data_dept=pickle.load(open(f'{path_dept}\{names}',"rb"))
                                                                
                                                                if data_dept[3]==Course and  data_dept[3]!=0: #engineering in course drop down== engineering in department file
                                                                        dept_names.add(data_dept[0])
                                                                else:
                                                                        pass
                                                        clicked_department=StringVar()   
                                                        drop_department_label=Label(student_manage_disp,text="S E L E C T   D E P A R T M E N T ",bg=frame_bg1,fg=label_fg)
                                                        
                                                        drop_department_label.place(x=20,y=350,height=20)

                                                        drop_department=OptionMenu(student_manage_disp,clicked_department,*dept_names)
                                                        drop_department.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                                        drop_department["highlightthickness"]=0
                                                        clicked_department.set("Select department")
                                                        drop_department.place(x=250,y=350,height=20)

                                                        BACK=Button(student_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=add_student)
                                                        BACK.place(x=800,y=50)
                                                        def SUBMIT():
                                                    
                                                                manage_students_add_list=[full_name.get(),roll.get(),registration_no.get(),e_mail.get(),clicked_department.get(),Course]
                                                                print(manage_students_add_list)
                                                                store_name=manage_students_add_list[0]
                                                                pickle.dump(manage_students_add_list,open(f'{path_students}\{store_name}.dat',"wb"))
                                                                messagebox.showinfo("Data Created",f'Data of {store_name} is created')
                                                                student_m()


                                                        submit=Button(student_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT)
                                                        submit.place(x=800,y=550)
                                                        
                                                        

                                                submit=Button(student_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=submit_course_name)
                                                submit.place(x=800,y=550)

                                                #BACK=Button(student_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=select_course)
                                                #BACK.place(x=800,y=50)
                                                
                                        

                                                

                                                
                                        select_course()
                                        
                                        
                                                
                                                
                        


                                # Department dropdown ... this will be based on the data entered in departments and it will show data according to choice selected in drop_course



                                             
                                                

                                     
                                        


                                

                              
                        def update_students():
                                for widgets in student_manage_disp.winfo_children():
                                        widgets.destroy()
                                # This will store info in the format [id,name,roll number,registration number,email] in the path
                                manage_students_add_list=[]
                                full_name=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                full_name.place(x=370,y=250,height=20)
                                full_namel=Label(student_manage_disp,text="E N T E R  N A M E  O F  S T U D E N T  Y O U  W A N T  T O  U P D A T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                full_namel.place(x=250,y=150,height=20)

                                BACK=Button(student_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=student_m)
                                BACK.place(x=800,y=50)


                                def submit():
                                        # This will take the name of student and we will use it to seach in the folder
                                        name=full_name.get()
                                        
                                         
                                        # NOW WE WILL FETCH DATA OF STUDENT(I.E COURSE AND WE WILL UPDATE FORM ACCORDING TO THE COURSE)
                                        

                                        for widgets in student_manage_disp.winfo_children():
                                            widgets.destroy()
                                        # This will search for and open the file to update
                                        listing=os.walk(path_students)
                                        root,directories,files=next(listing)

                                        file=f'{name}.dat'
                                        if file in files:
                                                
                                                        dta_=pickle.load(open(f'{path_students}\{file}',"rb"))


                                                        name_course_enrolled=dta_[5]
                                                        # Now we got the name of course that our student is enrolled in and now we will see the departments available in the course
                                                        
                                                                


                                                        insrt_name=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        insrt_name.place(x=250,y=100,height=20)
                                                        full_namel=Label(student_manage_disp,text="F U L L   N A M E",bg=frame_bg1,fg=label_fg)
                                                        full_namel.place(x=20,y=100,height=20)
                                                        insrt_name.insert(END,dta_[0])
                                                        insrt_name.config(state='disabled')

                                                        insert_roll=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        insert_roll.place(x=250,y=150,height=20)
                                                        roll_l=Label(student_manage_disp,text="R O L L   N U M B E R",bg=frame_bg1,fg=label_fg)
                                                        roll_l.place(x=20,y=150,height=20)
                                                        insert_roll.insert(0,dta_[1])

                                                        registration_no=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        registration_no.place(x=250,y=200,height=20)
                                                        registration_nol=Label(student_manage_disp,text="R E G I S T R A T I O N   N U M B E R",bg=frame_bg1,fg=label_fg)
                                                        registration_nol.place(x=20,y=200,height=20)
                                                        registration_no.insert(0,dta_[2])

                                                        e_mail=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                        e_mail.place(x=250,y=250,height=20)
                                                        e_maill=Label(student_manage_disp,text="E - M A I L ",bg=frame_bg1,fg=label_fg)
                                                        e_maill.place(x=20,y=250,height=20)
                                                        e_mail.insert(0,dta_[3])

                                                        # Reading course to create list of departments in the file
                                                        COURSE=Entry(student_manage_disp,width=30,relief="flat",fg=label_fg,bg="black")
                                                        COURSE.place(x=250,y=350,height=20)
                                                        COURSE1=Label(student_manage_disp,text="C O U R S E ",bg=frame_bg1,fg=label_fg)
                                                        COURSE1.place(x=20,y=350,height=20)
                                                        COURSE.insert(0,dta_[5])
                                                        COURSE.config(state='disabled')


                                                        set_var=StringVar()
                                                        ref=COURSE.get()
                                                        
                                                        order=os.walk(path_dept)
                                                        dep_data=set([])
                                                        root_,directiories_,files_=next(order)
                                                        for names in files_:
                                                                data_dept=pickle.load(open(f'{path_dept}\{names}',"rb"))
                                                                
                                                                if data_dept[3]==ref and  data_dept[3]!=0: #engineering in course drop down== engineering in department file
                                                                        dep_data.add(data_dept[0])
                                                                else:
                                                                        pass


                                                        dep=Label(student_manage_disp,text="D E P A R T M E N T ",bg=frame_bg1,fg=label_fg)
                                                        dep.place(x=20,y=300,height=20)                       
                                                        print(dep_data)
                                                        drop=OptionMenu(student_manage_disp,set_var,*dep_data)
                                                        drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                                        drop["highlightthickness"]=0
                                                        set_var.set("Select Department")

                                                        drop.place(x=250,y=300)


                                                        def SUBMIT():
                                                                dta_[0]=insrt_name.get()
                                                                dta_[1]=insert_roll.get()
                                                                dta_[2]=registration_no.get()
                                                                dta_[3]=e_mail.get()
                                                                dta_[4]=set_var.get()
                                                                
                                                                pickle.dump(dta_,open(f'{path_students}\{dta_[0]}.dat',"wb"))
                                                                messagebox.showinfo("Updated","Student data updated")
                                                                student_m()

                                                        submit=Button(student_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT)
                                                        submit.place(x=800,y=550)
                                                        BACK=Button(student_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=student_m)
                                                        BACK.place(x=800,y=50)
                                                        
                                                        
                                                        
                                                        

                                                        
                                        else:
                                                
                                                print("file not found")
                                                messagebox.showinfo("File not found","The data of student you are searching for is not found")
                                                update_students()
                                                        
                                                       
                                                        
                                                        
                                                        
                                                
                                                
                                submit=Button(student_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=submit)
                                submit.place(x=800,y=550)
                        
                        def delete_student():
                                for widgets in student_manage_disp.winfo_children():
                                            widgets.destroy()
                                del_name=Entry(student_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                del_name.place(x=370,y=250,height=20)
                                del1_namel=Label(student_manage_disp,text="E N T E R  N A M E  O F  S T U D E N T  Y O U  W A N T  T O  D E L E T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                del1_namel.place(x=250,y=150,height=20)
                                def del_data():
                                        name=del_name.get()
                                        try:
                                                os.remove(f'{path_students}\{name}.dat')
                                                messagebox.showinfo("Data Deleted",f'Data of {name} is deleted')
                                                
                                        except:
                                                messagebox.showinfo("Not found","Data not found")
                                BACK=Button(student_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=student_m)
                                BACK.place(x=800,y=50)

                                submit=Button(student_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=del_data)
                                submit.place(x=800,y=550)

                        #  IN STUDENT FRAME WE HAVE TO ADD BUTTONS OF ADD STUDENT,UPDATE,DELETE,GO BACK
                        add=Button(student_manage_frame,text="A D D    S T U D E N T",bg=frame_bg,fg=label_fg,relief="flat",command=add_student)
                        add.place(x=50,y=150)

                        UPDATE=Button(student_manage_frame,text="U P D A T E    S T U D E N T",bg=frame_bg,fg=label_fg,relief="flat",command=update_students)
                        UPDATE.place(x=35,y=250)

                        DELETE=Button(student_manage_frame,text="D E L E T E    S T U D E N T",bg=frame_bg,fg=label_fg,relief="flat",command=delete_student)
                        DELETE.place(x=35,y=350)

                
                ''' ------------------------------------------------------------------------------------------------------------------------------
                ------------------------------------------------------------------------------------------------------------------------------------
                ------------------------------------------------------------------------------------------------------------------------------------


                                                        HERE STARTS THE CODE OF EMPLOYEES TAB UNDER MANAGEMENT TAB

                 -----------------------------------------------------------------------------------------------------------------------------------------
                 ----------------------------------------------------------------------------------------------------------------------------------------
                 -------------------------------------------------------------------------------------------------------------------------------------                                       
                '''
                def employee_tab():
                        for widgets in dispframe.winfo_children():
                                widgets.destroy()
                        employee_manage_frame=Frame(dispframe,bg=frame_bg)
                        employee_manage_frame.place(x=0,y=0,height=650,width=220)

                        employee_manage_disp=Frame(dispframe,bg=frame_bg1)
                        employee_manage_disp.place(x=230,y=0,height=650,width=920)

                        my_employee=ttk.Treeview(employee_manage_disp )
                        s=ttk.Style()
                        #pick a theme
                        s.theme_use("clam")
                        # configure treeview colourd
                        s.configure('Treeview',rowheight=60,
                        background=frame_bg1,
                        foreground="white",
                        fieldbackground=frame_bg1                  
                        
                        )

                        s.configure('Treeview.Heading', background=frame_bg, foreground='white',relief="flat")

                        s.map('Treeview',background=[('selected','green')],foreground=[('selected','grey')])
                       # s.configure('Treeview',rowheight=60)
                        
                
                        def employee_info_m():
                                        #define columns
                                        my_employee['columns']=("id","Name","uid","Age","gender",)
                                        #formate our columns
                                        my_employee.column("#0",width=0,stretch=NO)
                                        my_employee.column("id",anchor=W,width=80)
                                        my_employee.column("Name",anchor=W,width=200)
                                        my_employee.column("uid",anchor=CENTER,width=200)
                                        my_employee.column("Age",anchor=W,width=200)
                                        my_employee.column("gender",anchor=W,width=250)

                                        #Create Heading
                                        my_employee.heading("#0",text="",anchor=W)
                                        my_employee.heading("id",text="ID",anchor=W)
                                        my_employee.heading("Name",text="Employee Name",anchor=W)
                                        my_employee.heading("uid",text="U-id",anchor=W)
                                        my_employee.heading("Age",text="Age",anchor=W)
                                        my_employee.heading("gender",text="Gender",anchor=W)
                                        my_employee.pack()

                                        #Opening files of data to show in table
                                        listing=os.walk(path_employees)
                                        for root_path,directiories, files in listing:
                                                #If name is found then it will open file for password
                                                count=1
                                                for file in files:
                                                        
                                                        data_list=pickle.load(open(f'{path_employees}\{file}',"rb"))
                                                        print(data_list)
                                                        my_employee.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[1],data_list[2],data_list[3]))
                                                        count+=1

                        employee_info_m()
                        def add_employee():
                                for widgets in employee_manage_disp.winfo_children():
                                        widgets.destroy()
                                # This will store info in the format [id,name,UID,AGE,GENDER] in the path
                                manage_students_add_list=[]
                                global gui
                                
                                full_name=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                full_name.place(x=150,y=100,height=20)
                                full_namel=Label(employee_manage_disp,text="F U L L   N A M E",bg=frame_bg1,fg=label_fg)
                                full_namel.place(x=40,y=100,height=20)

                                roll=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                roll.place(x=150,y=150,height=20)
                                roll_l=Label(employee_manage_disp,text="U N I Q U E   I D",bg=frame_bg1,fg=label_fg)
                                roll_l.place(x=20,y=150,height=20)

                                registration_no=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                registration_no.place(x=250,y=200,height=20)
                                registration_nol=Label(employee_manage_disp,text="              A G E         " ,bg=frame_bg1,fg=label_fg)
                                registration_nol.place(x=20,y=200,height=20)

                                e_mail=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                e_mail.place(x=250,y=250,height=20)
                                e_maill=Label(employee_manage_disp,text="  G E N D E R" ,bg=frame_bg1,fg=label_fg)
                                e_maill.place(x=20,y=250,height=20)

                                BACK=Button(employee_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=employee_tab)
                                BACK.place(x=800,y=50)
                                def SUBMIT():
                                        
                                        manage_students_add_list=[full_name.get(),roll.get(),registration_no.get(),e_mail.get()]
                                        print(manage_students_add_list)
                                        store_name=manage_students_add_list[0]
                                        pickle.dump(manage_students_add_list,open(f'{path_employees}\{store_name}.dat',"wb"))

                                submit=Button(employee_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT)
                                submit.place(x=800,y=550)

                        def update_employees():
                                for widgets in employee_manage_disp.winfo_children():
                                        widgets.destroy()
                                # This will store info in the format [id,name,roll number,registration number,email] in the path
                                manage_students_add_list=[]
                                full_name=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                full_name.place(x=370,y=250,height=20)
                                full_namel=Label(employee_manage_disp,text="E N T E R  N A M E  O F  E M P L O Y E E  Y O U  W A N T  T O  U P D A T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                full_namel.place(x=250,y=150,height=20)

                                BACK=Button(employee_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=employee_tab)
                                BACK.place(x=800,y=50)


                                def submit():
                                        # This will take the name of student and we will use it to seach in the folder
                                        name=full_name.get()
                                        for widgets in employee_manage_disp.winfo_children():
                                            widgets.destroy()
                                        # This will search for and open the file to update
                                        listing=os.walk(path_employees)
                                        for root,directories,files in listing:
                                                for file in files:
                                                        if file==f'{name}.dat':
                                                                dta=pickle.load(open(f'{path_employees}\{file}',"rb"))
                                                                insrt_name=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                                insrt_name.place(x=150,y=100,height=20)
                                                                full_namel=Label(employee_manage_disp,text="F U L L   N A M E",bg=frame_bg1,fg=label_fg)
                                                                full_namel.place(x=40,y=100,height=20)
                                                                insrt_name.insert(END,dta[0])

                                                                insert_roll=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                                insert_roll.place(x=150,y=150,height=20)
                                                                roll_l=Label(employee_manage_disp,text="R O L L   N U M B E R",bg=frame_bg1,fg=label_fg)
                                                                roll_l.place(x=20,y=150,height=20)
                                                                insert_roll.insert(0,dta[1])

                                                                registration_no=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                                registration_no.place(x=250,y=200,height=20)
                                                                registration_nol=Label(employee_manage_disp,text="R E G I S T R A T I O N   N U M B E R",bg=frame_bg1,fg=label_fg)
                                                                registration_nol.place(x=20,y=200,height=20)
                                                                registration_no.insert(0,dta[2])

                                                                e_mail=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                                e_mail.place(x=250,y=250,height=20)
                                                                e_maill=Label(employee_manage_disp,text="E - M A I L ",bg=frame_bg1,fg=label_fg)
                                                                e_maill.place(x=20,y=250,height=20)
                                                                e_mail.insert(0,dta[3])


                                                                def SUBMIT():
                                                                        dta[0]=insrt_name.get()
                                                                        dta[1]=insert_roll.get()
                                                                        dta[2]=registration_no.get()
                                                                        dta[3]=e_mail.get()
                                                                        pickle.dump(dta,open(f'{path_employees}\{dta[0]}.dat',"wb"))
                                                                        

                                                                submit=Button(employee_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT)
                                                                submit.place(x=800,y=550)
                                                                BACK=Button(employee_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=employee_tab)
                                                                BACK.place(x=800,y=50)
                                                                

                                                                
                                                        else:
                                                                print("file not found")
                                                        

                                submit=Button(employee_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=submit)
                                submit.place(x=800,y=550)
                        
                        def delete_employee():
                                for widgets in employee_manage_disp.winfo_children():
                                            widgets.destroy()
                                del_name=Entry(employee_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                del_name.place(x=370,y=250,height=20)
                                del1_namel=Label(employee_manage_disp,text="E N T E R  N A M E  O F  E M P L O Y E E  Y O U  W A N T  T O  D E L E T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                del1_namel.place(x=250,y=150,height=20)
                                def del_data():
                                        name=del_name.get()
                                        os.remove(f'{path_employees}\{name}.dat')
                                        print("Deleted data of "+name)
                                BACK=Button(employee_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=employee_tab)
                                BACK.place(x=800,y=50)

                                submit=Button(employee_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=del_data)
                                submit.place(x=800,y=550)

                        #  IN STUDENT FRAME WE HAVE TO ADD BUTTONS OF ADD STUDENT,UPDATE,DELETE,GO BACK
                        add=Button(employee_manage_frame,text="A D D    E M P L O Y E E",bg=frame_bg,fg=label_fg,relief="flat",command=add_employee)
                        add.place(x=50,y=150)

                        UPDATE=Button(employee_manage_frame,text="U P D A T E    E M P L O Y E E",bg=frame_bg,fg=label_fg,relief="flat",command=update_employees)
                        UPDATE.place(x=35,y=250)

                        DELETE=Button(employee_manage_frame,text="D E L E T E    E M P L O Y E E",bg=frame_bg,fg=label_fg,relief="flat",command=delete_employee)
                        DELETE.place(x=35,y=350)
                        
                ''' ------------------------------------------------------------------------------------------------------------------------------
                ------------------------------------------------------------------------------------------------------------------------------------
                ------------------------------------------------------------------------------------------------------------------------------------


                                                        HERE STARTS THE CODE OF DEPARTMENT TAB UNDER MANAGEMENT TAB

                 -----------------------------------------------------------------------------------------------------------------------------------------
                 ----------------------------------------------------------------------------------------------------------------------------------------
                 -------------------------------------------------------------------------------------------------------------------------------------                                       
                '''
                def department_tab():
                        stu_path1=os.walk(f'{path_course}')
                        stu_path=os.walk(f'{path_dept}')
                        root_path1,directiories1,files1 = next(stu_path1)
                        root_path,directiories,files = next(stu_path)
                        dept_names=[]
                        Course_Names=[]
                        for item in files1:
                                
                                Course_Names.append(item.replace('.dat',''))

                        for items in range(len(files)):
                                dept_names.append(files[items].replace('.dat',''))


                        if len(files1)==0:
                                x="no_course"
                        
                        else:
                                if len(files)==0:
                                        x="no_dept"
                                else:
                                        x="yes"

                        # check if a course has been deleted or not
                        
                        
                        
                        
                       
                        for j in files:
                                                        
                                open_s=pickle.load(open(f'{path_dept}\{j}',"rb"))
                                
                                if open_s[3] not  in Course_Names:
                                        os.remove(f'{path_dept}\{j}')
                                else:
                                        pass
                        


                        for widgets in dispframe.winfo_children():

                                widgets.destroy()
                        department_manage_frame=Frame(dispframe,bg=frame_bg)
                        department_manage_frame.place(x=0,y=0,height=650,width=220)

                        department_manage_disp=Frame(dispframe,bg=frame_bg1)
                        department_manage_disp.place(x=230,y=0,height=650,width=920)

                        my_department=ttk.Treeview(department_manage_disp)
                        s=ttk.Style()
                        #pick a theme
                        s.theme_use("clam")
                        # configure treeview colourd
                        s.configure('Treeview',rowheight=60,
                        background=frame_bg1,
                        foreground="white",
                        fieldbackground=frame_bg1                  
                        
                        )

                        s.configure('Treeview.Heading', background=frame_bg, foreground='white',relief="flat")

                        s.map('Treeview',background=[('selected','green')],foreground=[('selected','grey')])
                        
                        def department_info_m():
                                        #define columns
                                        my_department['columns']=("id","dept_name","dept_id","hod","COURSE")
                                        #formate our columns
                                        my_department.column("#0",width=0,stretch=NO)
                                        my_department.column("id",anchor=W,width=40)
                                        my_department.column("dept_name",anchor=W,width=200)
                                        my_department.column("dept_id",anchor=CENTER,width=200)
                                        my_department.column("hod",anchor=W,width=200)
                                        my_department.column("COURSE",anchor=W,width=200)
                                       

                                        #Create Heading
                                        my_department.heading("#0",text="",anchor=W)
                                        my_department.heading("id",text="S.No.",anchor=W)
                                        my_department.heading("dept_name",text="Department Name",anchor=W)
                                        my_department.heading("dept_id",text="Department Id",anchor=W)
                                        my_department.heading("hod",text="Head of Department",anchor=W)
                                        my_department.heading("COURSE",text="Under Course",anchor=W)
                                        
                                        my_department.pack()

                                        #Opening files of data to show in table
                                        listing=os.walk(path_dept)
                                        for root_path,directiories, files in listing:
                                                #If name is found then it will open file for password
                                                count=1
                                                for file in files:
                                                        
                                                        data_list=pickle.load(open(f'{path_dept}\{file}',"rb"))
                                                        print(data_list)
                                                        my_department.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[1],data_list[2],data_list[3]))
                                                        count+=1
                        department_info_m()

                        def add_department():
                                if x=="no_course":
                                        messagebox.showinfo(department_manage_disp,"No course is added, hence you cannot add any departments")
                                else:

                                        for widgets in department_manage_disp.winfo_children():
                                                widgets.destroy()
                                        # This will store info in the format [id,name,UID,AGE,GENDER] in the path
                                        manage_students_add_list=[]
                                        global gui
                                        
                                        full_name=Entry(department_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                        full_name.place(x=250,y=100,height=20)
                                        full_namel=Label(department_manage_disp,text="D E P A R T M E N T  N A M E",bg=frame_bg1,fg=label_fg)
                                        full_namel.place(x=40,y=100,height=20)

                                        roll=Entry(department_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                        roll.place(x=250,y=150,height=20)
                                        roll_l=Label(department_manage_disp,text="D E P A R T M E N T   I D",bg=frame_bg1,fg=label_fg)
                                        roll_l.place(x=65,y=150,height=20)
                                        
                                        drop_label=Label(department_manage_disp,text="S E L E C T  C O U R S E",bg=frame_bg1,fg=label_fg)
                                        drop_label.place(x=70,y=250,height=20)
                                        # This is drop down menu
                                        menu_list=os.walk(f'{path_course}')
                                        root,directories, files=next(menu_list)
                                        clicked= StringVar()
                                        new_list=[]
                                        for items in range(len(files)):
                                                new_list.append(files[items].replace('.dat',''))
                                                
                                        clicked.set(new_list[0])
                                        
                                        drop=OptionMenu(department_manage_disp, clicked ,*new_list)
                                        drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                        drop["highlightthickness"]=0
                                        drop.place(x=250,y=250,height=20)
                                        
                                        registration_no=Entry(department_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                        registration_no.place(x=250,y=200,height=20)
                                        registration_nol=Label(department_manage_disp,text=" H E A D   O F   D E P A R T M E N T" ,bg=frame_bg1,fg=label_fg)
                                        registration_nol.place(x=10,y=200,height=20)

                                        

                                        BACK=Button(department_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=department_tab)
                                        BACK.place(x=800,y=50)
                                        def SUBMIT():
                                                
                                                manage_students_add_list=[full_name.get(),roll.get(),registration_no.get(),clicked.get()]
                                                print(manage_students_add_list)
                                                store_name=manage_students_add_list[0]
                                                pickle.dump(manage_students_add_list,open(f'{path_dept}\{store_name}.dat',"wb"))
                                                messagebox.showinfo("Department Created",f'Department added')
                                                department_tab()

                                        submit=Button(department_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT)
                                        submit.place(x=800,y=550)
                        def update_department():
                                if (x=="no_course"):
                                        messagebox.showinfo(department_manage_disp,"No course, add course first")
                                elif (x=="no_dept"):
                                        messagebox.showinfo(department_manage_disp,"No Department, hence you cannot update department")
                                else:
                                        for widgets in department_manage_disp.winfo_children():
                                                widgets.destroy()
                                        # This will store info in the format [id,name,roll number,registration number,email] in the path
                                        manage_students_add_list=[]

                                        clicked=StringVar()
                                        clicked.set(" \t \t \t")
                                        length=len(clicked.get())
                                        
                                                                                   
                                             
                                        


                                        
                                        drop=OptionMenu(department_manage_disp,clicked,*dept_names)
                                        drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                        drop["highlightthickness"]=0
                                        
                                        drop.place(x=400,y=250,height=21)

                                        '''full_name=Entry(department_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                        full_name.place(x=370,y=250,height=20)'''
                                        full_namel=Label(department_manage_disp,text="E N T E R  N A M E  O F  D E P A R T M E N T  Y O U  W A N T  T O  U P D A T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                        full_namel.place(x=250,y=150,height=20)

                                        BACK=Button(department_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=department_tab)
                                        BACK.place(x=800,y=50)


                                        def submit():
                                                # This will take the name of student and we will use it to seach in the folder
                                                name=clicked.get()
                                                for widgets in department_manage_disp.winfo_children():
                                                        widgets.destroy()
                                                # This will search for and open the file to update
                                                listing=os.walk(path_dept)
                                                for root,directories,files in listing:
                                                        for file in files:
                                                                if file==f'{name}.dat':
                                                                        dta=pickle.load(open(f'{path_dept}\{file}',"rb"))
                                                                        name_l=Label(department_manage_disp,text="D E P A R T M E N T   N A M E ",bg=frame_bg1,fg=label_fg)
                                                                        name_l.place(x=20,y=100,height=20)
                                                                        insrt_name=Entry(department_manage_disp,width=30,bg=frame_bg,relief="flat",fg="black")
                                                                        insrt_name.insert(END,dta[0])
                                                                        insrt_name.config(state='disabled')
                                                                        insrt_name.place(x=250,y=100,height=20)

                                                                        insert_roll=Entry(department_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                                        insert_roll.place(x=250,y=150,height=20)
                                                                        roll_l=Label(department_manage_disp,text="D E P A R T M E N T   I D",bg=frame_bg1,fg=label_fg)
                                                                        roll_l.place(x=20,y=150,height=20)
                                                                        insert_roll.insert(0,dta[1])

                                                                        registration_no=Entry(department_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                                        registration_no.place(x=250,y=200,height=20)
                                                                        registration_nol=Label(department_manage_disp,text="H E A D  O F  D E P A R T M E N T",bg=frame_bg1,fg=label_fg)
                                                                        registration_nol.place(x=20,y=200,height=20)
                                                                        registration_no.insert(0,dta[2])

                                                                        drop_label=Label(department_manage_disp,text="C O U R S E",bg=frame_bg1,fg=label_fg)
                                                                        drop_label.place(x=20,y=250,height=20)
                                                                        # This is drop down menu
                                                                        menu_list=os.walk(f'{path_course}')
                                                                        root,directories, files=next(menu_list)
                                                                        clicked_submit= StringVar()
                                                                        new_list=[]
                                                                        for items in range(len(files)):
                                                                                new_list.append(files[items].replace('.dat',''))
                                                                                
                                                                        clicked_submit.set(new_list[0])
                                                                        
                                                                        drop=OptionMenu(department_manage_disp, clicked_submit ,new_list[0])
                                                                        drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                                                        drop["highlightthickness"]=0
                                                                        drop.place(x=250,y=250,height=20)
                                                                        drop.config(state='disabled')

                                                                        


                                                                        def SUBMIT():
                                                                                dta[0]=insrt_name.get()
                                                                                dta[1]=insert_roll.get()
                                                                                dta[2]=registration_no.get()
                                                                                dta[3]=clicked_submit.get()
                                                                                
                                                                                pickle.dump(dta,open(f'{path_dept}\{dta[0]}.dat',"wb"))
                                                                                messagebox.showinfo("Data Updated","Department updated")
                                                                                department_tab()
                                                                                

                                                                        submit=Button(department_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT)
                                                                        submit.place(x=800,y=550)
                                                                        BACK=Button(department_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=department_tab)
                                                                        BACK.place(x=800,y=50)
                                                                        break

                                                                        
                                                                else:
                                                                        print("file not found")
                                                                

                                        submit=Button(department_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=submit)
                                        submit.place(x=800,y=550)
                        
                        def delete_department():
                                if x=="no_course":
                                        messagebox.showinfo(department_manage_disp,"No course, so you cannot delete from any course")
                                elif x=="no_dept":
                                        messagebox.showinfo(department_manage_disp,"No department, add department first")
                                else:

                                        for widgets in department_manage_disp.winfo_children():
                                                widgets.destroy()
                                        clicked=StringVar()
                                        clicked.set(" \t \t \t")
                                        length=len(clicked.get())
                                        
                                                                                        
                                                
                                        


                                        
                                        drop=OptionMenu(department_manage_disp,clicked,*dept_names)
                                        drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                        drop["highlightthickness"]=0
                                        
                                        drop.place(x=400,y=250,height=21)
                                        del1_namel=Label(department_manage_disp,text="E N T E R  N A M E  O F  D E P A R T M E N T  Y O U  W A N T  T O  D E L E T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                        del1_namel.place(x=250,y=150,height=20)
                                        def del_data():
                                                name=clicked.get()
                                                del_course.append(name)
                                                
                                                os.remove(f'{path_dept}\{name}.dat')
                                                messagebox.showinfo("Data Deleted","Department deleted")
                                                department_tab()
                                        BACK=Button(department_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=department_tab)
                                        BACK.place(x=800,y=50)

                                        submit=Button(department_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=del_data)
                                        submit.place(x=800,y=550)

                                #  IN STUDENT FRAME WE HAVE TO ADD BUTTONS OF ADD STUDENT,UPDATE,DELETE,GO BACK
                        add=Button(department_manage_frame,text="A D D    D E P A R T M E N T",bg=frame_bg,fg=label_fg,relief="flat",command=add_department)
                        add.place(x=50,y=150)

                        UPDATE=Button(department_manage_frame,text="U P D A T E    D E P A R T M E N T",bg=frame_bg,fg=label_fg,relief="flat",command=update_department)
                        UPDATE.place(x=35,y=250)

                        DELETE=Button(department_manage_frame,text="D E L E T E    D E P A R T M E N T",bg=frame_bg,fg=label_fg,relief="flat",command=delete_department)
                        DELETE.place(x=35,y=350)
                                

                ''' ------------------------------------------------------------------------------------------------------------------------------
                ------------------------------------------------------------------------------------------------------------------------------------
                ------------------------------------------------------------------------------------------------------------------------------------


                                                        HERE STARTS THE CODE OF COURSE TAB UNDER MANAGEMENT TAB

                 -----------------------------------------------------------------------------------------------------------------------------------------
                 ----------------------------------------------------------------------------------------------------------------------------------------
                 -------------------------------------------------------------------------------------------------------------------------------------                                       
                '''
                def course_tab():

                        check_course=os.walk(f'{path_course}')
                        root,directories,files = next(check_course)
                        course_names=[]
                        for items in range(len(files)):
                                course_names.append(files[items].replace('.dat','').upper())

                        if len(course_names)==0:
                                x="no"
                        else:
                                x="yes"



                        for widgets in dispframe.winfo_children():
                                widgets.destroy()
                        course_manage_frame=Frame(dispframe,bg=frame_bg)
                        course_manage_frame.place(x=0,y=0,height=650,width=220)

                        course_manage_disp=Frame(dispframe,bg=frame_bg1)
                        course_manage_disp.place(x=230,y=0,height=650,width=920)

                        my_course=ttk.Treeview(course_manage_disp )
                        s=ttk.Style(course_manage_disp)
                        
# set ttk theme to "clam" which support the fieldbackground option
                        s=ttk.Style()
                        #pick a theme
                        s.theme_use("clam")
                        # configure treeview colourd
                        s.configure('Treeview',rowheight=60,
                        background=frame_bg1,
                        foreground="white",
                        fieldbackground=frame_bg1                  
                        
                        )

                        s.configure('Treeview.Heading', background=frame_bg, foreground='white',relief="flat")

                        s.map('Treeview',background=[('selected','green')],foreground=[('selected','grey')])
                        
                        def course_info_m():
                                        #define columns
                                        my_course['columns']=("id","course_name","course_id","years_of_course","students_enrolled")
                                        #formate our columns
                                        my_course.column("#0",width=0,stretch=NO)
                                        my_course.column("id",anchor=W,width=80)
                                        my_course.column("course_name",anchor=W,width=200)
                                        my_course.column("course_id",anchor=W,width=200)
                                        my_course.column("years_of_course",anchor=CENTER,width=200)
                                        my_course.column("students_enrolled",anchor=W,width=200)
                                       

                                        #Create Heading
                                        my_course.heading("#0",text="",anchor=W)
                                        my_course.heading("id",text="S.No.",anchor=W)
                                        my_course.heading("course_name",text="Course Name",anchor=W)
                                        my_course.heading("course_id",text="Course Id",anchor=W)
                                        my_course.heading("years_of_course",text="Years",anchor=W)
                                        my_course.heading("students_enrolled",text="Students",anchor=W)
                                        
                                        my_course.pack()

                                        #Opening files of data to show in table
                                        listing=os.walk(path_course)
                                        for root_path,directiories, files in listing:
                                                #If name is found then it will open file for password
                                                count=1
                                                for file in files:
                                                        
                                                        data_list=pickle.load(open(f'{path_course}\{file}',"rb"))
                                                        print(data_list)
                                                        my_course.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[1],data_list[2],data_list[3]))
                                                        count+=1
                        course_info_m()

                        def add_course():

                                for widgets in course_manage_disp.winfo_children():
                                        widgets.destroy()
                                # This will store info in the format [id,name,UID,AGE,GENDER] in the path
                                manage_students_add_list=[]
                                global gui
                                
                                full_name=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                full_name.place(x=250,y=100,height=20)
                                full_namel=Label(course_manage_disp,text="C O U R S E  N A M E",bg=frame_bg1,fg=label_fg)
                                full_namel.place(x=40,y=100,height=20)

                                roll=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                roll.place(x=250,y=150,height=20)
                                roll_l=Label(course_manage_disp,text="C O U R S E   I D",bg=frame_bg1,fg=label_fg)
                                roll_l.place(x=65,y=150,height=20)

                                registration_no=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                registration_no.place(x=250,y=200,height=20)
                                registration_nol=Label(course_manage_disp,text=" Y E A R S " ,bg=frame_bg1,fg=label_fg)
                                registration_nol.place(x=95,y=200,height=20)

                                e_mail=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                e_mail.place(x=250,y=250,height=20)
                                e_maill=Label(course_manage_disp,text="S T U D E N T S" ,bg=frame_bg1,fg=label_fg)
                                e_maill.place(x=70,y=250,height=20)

                                

                                BACK=Button(course_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=course_tab)
                                BACK.place(x=800,y=50)
                                def SUBMIT_C():
                                        
                                        check=full_name.get()
                                        if check.upper() in course_names:
                                                messagebox.showinfo("Course Exists","There is already a course with same name")
                                                
                                        else:
                                
                                                manage_students_add_list=[check,roll.get(),registration_no.get(),e_mail.get()]
                                                store_name=manage_students_add_list[0]
                                                pickle.dump(manage_students_add_list,open(f'{path_course}\{store_name}.dat',"wb"))
                                                messagebox.showinfo("Data created","Course created")
                                                course_tab()

                                submit=Button(course_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT_C)
                                submit.place(x=800,y=550)

                        def update_course():
                                if x=="no":
                                        messagebox.showinfo(course_manage_disp,"There are no courses so you cannot update any")
                                else:
                                
                                        for widgets in course_manage_disp.winfo_children():
                                                widgets.destroy()
                                        # This will store info in the format [id,name,roll number,registration number,email] in the path
                                        manage_students_add_list=[]

                                        clicked=StringVar()
                                        clicked.set(" \t \t \t")
                                        length=len(clicked.get())
                                        
                                                                                   
                                             
                                        


                                        
                                        drop=OptionMenu(course_manage_disp,clicked,*course_names)
                                        drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                        drop["highlightthickness"]=0
                                        
                                        drop.place(x=400,y=250,height=21)
                                        

                                        
                                        full_namel=Label(course_manage_disp,text="S E L E C T  N A M E  O F  C O U R S E  Y O U  W A N T  T O  U P D A T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                        full_namel.place(x=250,y=150,height=20)

                                        
                                        
                                        BACK=Button(course_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=course_tab)
                                        BACK.place(x=800,y=50)


                                        def submit_u():
                                                # This will take the name of student and we will use it to seach in the folder
                                                
                                                name=clicked.get()
                                                for widgets in course_manage_disp.winfo_children():
                                                        widgets.destroy()
                                                # This will search for and open the file to update
                                                listing=os.walk(path_course)
                                                root,directories,files =next(listing) 
                                                file__s=f'{name}.dat'
                                                
                                                        
                                                dta=pickle.load(open(f'{path_course}\{file__s}',"rb"))
                                                insrt_name=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg="black")
                                                insrt_name.insert(END,dta[0])
                                                insrt_name.config(state='disabled')
                                                
                                                insrt_name.place(x=250,y=100,height=20)
                                                full_namel=Label(course_manage_disp,text="C O U R S E   N A M E",bg=frame_bg1,fg=label_fg)
                                                full_namel.place(x=50,y=100,height=20)
                                                

                                                insert_roll=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                insert_roll.place(x=250,y=150,height=20)
                                                roll_l=Label(course_manage_disp,text="C O U R S E   I D",bg=frame_bg1,fg=label_fg)
                                                roll_l.place(x=80,y=150,height=20)
                                                insert_roll.insert(0,dta[1])

                                                registration_no=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                registration_no.place(x=250,y=200,height=20)
                                                registration_nol=Label(course_manage_disp,text="Y E A R S",bg=frame_bg1,fg=label_fg)
                                                registration_nol.place(x=110,y=200,height=20)
                                                registration_no.insert(0,dta[2])

                                                e_mail=Entry(course_manage_disp,width=30,bg=frame_bg,relief="flat",fg=label_fg)
                                                e_mail.place(x=250,y=250,height=20)
                                                e_maill=Label(course_manage_disp,text="S T U D E N T S" ,bg=frame_bg1,fg=label_fg)
                                                e_maill.place(x=80,y=250,height=20)
                                                e_mail.insert(0,dta[3])

                                                


                                                def SUBMIT_U():
                                                        
                                                        dta[0]=insrt_name.get()
                                                        
                                                        dta[1]=insert_roll.get()
                                                        dta[2]=registration_no.get()
                                                        dta[3]=e_mail.get()
                                                        
                                                        pickle.dump(dta,open(f'{path_course}\{dta[0]}.dat',"wb"))
                                                        messagebox.showinfo("Course Updated",f'{dta[0]} Updated')
                                                        course_tab()

                                                submit=Button(course_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=SUBMIT_U)
                                                submit.place(x=800,y=550)
                                                BACK=Button(course_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=course_tab)
                                                BACK.place(x=800,y=50)
                                                
                                                

                                                        
                                                
                                                                

                                        submit=Button(course_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=submit_u)
                                        submit.place(x=800,y=550)
                        
                        def delete_course():
                                if x=="no":
                                        messagebox.showinfo(course_manage_disp,"There are no courses so you cannot delete any")
                                else:
                                        for widgets in course_manage_disp.winfo_children():
                                                widgets.destroy()
                                        clicked=StringVar()
                                        clicked.set(" \t \t \t")
                                        length=len(clicked.get())
                                        
                                                                                        
                                                
                                        


                                        
                                        drop=OptionMenu(course_manage_disp,clicked,*course_names)
                                        drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                                        drop["highlightthickness"]=0
                                        
                                        drop.place(x=400,y=250,height=21)
                                        del1_namel=Label(course_manage_disp,text="E N T E R  N A M E  O F  C O U R S E  Y O U  W A N T  T O  D E L E T E  D A T A  O F",bg=frame_bg1,fg=label_fg)
                                        del1_namel.place(x=250,y=150,height=20)
                                        def del_data():
                                                name=clicked.get()
                                                del_course.append(name)
                                                
                                                os.remove(f'{path_course}\{name}.dat')
                                                messagebox.showinfo("Course Deleted",f'Data of {name} is deleted')
                                                course_tab()
                                        BACK=Button(course_manage_disp,text=" B A C K ",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=course_tab)
                                        BACK.place(x=800,y=50)

                                        submit=Button(course_manage_disp,text="S U B M I T",font=(10),bg=frame_bg1,fg=label_fg,relief="flat",command=del_data)
                                        submit.place(x=800,y=550)

                        #  IN STUDENT FRAME WE HAVE TO ADD BUTTONS OF ADD STUDENT,UPDATE,DELETE,GO BACK
                        add=Button(course_manage_frame,text="A D D    C O U R S E",bg=frame_bg,fg=label_fg,relief="flat",command=add_course)
                        add.place(x=50,y=150)

                        UPDATE=Button(course_manage_frame,text="U P D A T E    C O U R S E",bg=frame_bg,fg=label_fg,relief="flat",command=update_course)
                        UPDATE.place(x=35,y=250)

                        DELETE=Button(course_manage_frame,text="D E L E T E    C O U R S E",bg=frame_bg,fg=label_fg,relief="flat",command=delete_course)
                        DELETE.place(x=35,y=350)
                        
















































                # main manage fucntion to be called when manage button is clicked
                def manage_func():
                        for widgets in dispframe.winfo_children():
                                widgets.destroy()
                        def student():
                                #stu_path=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\Data")
                                #root_path,directiories,files = next(stu_path)      
                                total_students=Button(dispframe,text=f'S T U D E N T S',bg=frame_bg,relief="flat",fg=label_fg,command=student_m)
                                total_students.place(x=100,y=70,height=150,width=150)
                        
                        def employee():
                        # stu_path=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\employees")
                        # root_path,directiories,files = next(stu_path)      
                                total_students=Button(dispframe,text=f'E M P L O  Y E E S',bg=frame_bg,relief="flat",fg=label_fg,command=employee_tab)
                                total_students.place(x=500,y=70,height=150,width=150)

                        def department():
                        # stu_path=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\departments")
                        # root_path,directiories,files = next(stu_path)      
                                total_students=Button(dispframe,text=f'D E P A R T M E N T',bg=frame_bg,relief="flat",fg=label_fg,command=department_tab)
                                total_students.place(x=900,y=70,height=150,width=150)

                        def course():
                                #stu_path=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\Data")
                                #root_path,directiories,files = next(stu_path)      
                                total_students=Button(dispframe,text=f'C O U R S E',bg=frame_bg,relief="flat",fg=label_fg,command=course_tab)
                                total_students.place(x=100,y=350,height=150,width=150)
                        
                        '''def section():
                        # stu_path=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\employees")
                        # root_path,directiories,files = next(stu_path)      
                                total_students=Button(dispframe,text=f'S E C T I O N',bg=frame_bg,relief="flat",fg=label_fg)
                                total_students.place(x=500,y=350,height=150,width=150)

                        def batch():
                        # stu_path=os.walk("C:\\Users\Sanjay-pc\Desktop\College Mini Project\App_data\departments")
                        # root_path,directiories,files = next(stu_path)      
                                total_students=Button(dispframe,text=f'B A T C H ',bg=frame_bg,relief="flat",fg=label_fg)
                                total_students.place(x=900,y=350,height=150,width=150)'''
                        student()
                        employee()
                        department()
                        course()#,section(),batch()

                def view():
                        #new frame inside dispframe to add scrollbar to 
                        for widgets in dispframe.winfo_children():
                                widgets.destroy()
                        my_student1=ttk.Treeview(dispframe)
                        my_emp=ttk.Treeview(dispframe)
                        my_course1=ttk.Treeview(dispframe)
                        my_dept=ttk.Treeview(dispframe)
                        s=ttk.Style()
                        #pick a theme
                        s.theme_use("clam")
                        # configure treeview colourd
                        s.configure('Treeview',rowheight=20,
                        background=frame_bg1,
                        foreground="white",
                        fieldbackground=frame_bg1                  
                        
                        )

                        s.configure('Treeview.Heading', background=frame_bg, foreground='white',relief="flat")

                        s.map('Treeview',background=[('selected','green')],foreground=[('selected','grey')])
                        def student_info():
                                #define columns
                                my_student1['columns']=("id","Name","Email","Gender")
                                #formate our columns
                                my_student1.column("#0",width=0,stretch=NO)
                                my_student1.column("id",anchor=W,width=25)
                                my_student1.column("Name",anchor=W,width=120)
                                my_student1.column("Email",anchor=CENTER,width=150)
                                my_student1.column("Gender",anchor=W,width=120)

                                #Create Heading
                                my_student1.heading("#0",text="",anchor=W)
                                my_student1.heading("id",text="ID",anchor=W)
                                my_student1.heading("Name",text="Student Name",anchor=W)
                                my_student1.heading("Email",text="E-mail",anchor=W)
                                my_student1.heading("Gender",text="gender",anchor=W)
                                my_student1.place(x=70,y=60)

                                #Opening files of data to show in table
                                listing=os.walk(path_students)
                                for root_path,directiories, files in listing:
                                        #If name is found then it will open file for password
                                        count=1
                                        for file in files:
                                                data_list=pickle.load(open(f'{path_students}\{file}',"rb"))
                                                print(data_list)
                                                my_student1.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[2],data_list[1]))
                                                count+=1
                        
                        def employee_info():
                                #define columns
                                my_emp['columns']=("id","Name","uid","Age","gender",)
                                #formate our columns
                                my_emp.column("#0",width=0,stretch=NO)
                                my_emp.column("id",anchor=W,width=40)
                                my_emp.column("Name",anchor=W,width=120,minwidth=100,stretch=NO)
                                my_emp.column("uid",anchor=CENTER,width=100,stretch=NO)
                                my_emp.column("Age",anchor=W,width=75)
                                my_emp.column("gender",anchor=W,width=75)

                                #Create Heading
                                my_emp.heading("#0",text="",anchor=W)
                                my_emp.heading("id",text="ID",anchor=W)
                                my_emp.heading("Name",text="Employee Name",anchor=W)
                                my_emp.heading("uid",text="U-id",anchor=W)
                                my_emp.heading("Age",text="Age",anchor=W)
                                my_emp.heading("gender",text="Gender",anchor=W)
                                my_emp.place(x=650,y=60)

                                #Opening files of data to show in table
                                listing=os.walk(path_employees)
                                for root_path,directiories, files in listing:
                                        #If name is found then it will open file for password
                                        count=1
                                        for file in files:
                                                data_list=pickle.load(open(f'{path_employees}\{file}',"rb"))
                                                print(data_list)
                                                my_emp.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[2],data_list[1],data_list[2]))
                                                count+=1
                        def course_info():
                                #define columns
                                my_course1['columns']=("id","course_name","course_id","years_of_course","students_enrolled")
                                        #formate our columns
                                my_course1.column("#0",width=0,stretch=NO)
                                my_course1.column("id",anchor=W,width=25)
                                my_course1.column("course_name",anchor=W,width=120)
                                my_course1.column("course_id",anchor=W,width=100)
                                my_course1.column("years_of_course",anchor=CENTER,width=75)
                                my_course1.column("students_enrolled",anchor=W,width=100)
                                

                                #Create Heading
                                my_course1.heading("#0",text="",anchor=W)
                                my_course1.heading("id",text="S.No.",anchor=W)
                                my_course1.heading("course_name",text="Course Name",anchor=W)
                                my_course1.heading("course_id",text="Course Id",anchor=W)
                                my_course1.heading("years_of_course",text="Years",anchor=W)
                                my_course1.heading("students_enrolled",text="Students",anchor=W)
                                
                                my_course1.place(x=70,y=350)

                                #Opening files of data to show in table
                                listing=os.walk(path_course)
                                for root_path,directiories, files in listing:
                                        #If name is found then it will open file for password
                                        count=1
                                        for file in files:
                                                data_list=pickle.load(open(f'{path_course}\{file}',"rb"))
                                                print(data_list)
                                                my_course1.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[2],data_list[1],data_list[2]))
                                                count+=1
                        def dep_info():
                                #define columns
                                my_dept['columns']=("id","Name","Email","Gender")
                                #formate our columnscourse       
                                my_dept.column("#0",width=0,stretch=NO)
                                my_dept.column("id",anchor=W,width=25)
                                my_dept.column("Name",anchor=W,width=120)
                                my_dept.column("Email",anchor=CENTER,width=150)
                                my_dept.column("Gender",anchor=W,width=120)

                                #Create Heading
                                my_dept.heading("#0",text="",anchor=W)
                                my_dept.heading("id",text="ID",anchor=W)
                                my_dept.heading("Name",text="Department Name",anchor=W)
                                my_dept.heading("Email",text="HOD",anchor=W)
                                my_dept.heading("Gender",text="Dept-Id",anchor=W)
                                my_dept.place(x=650,y=350)

                                #Opening files of data to show in table
                                listing=os.walk(path_dept)
                                for root_path,directiories, files in listing:
                                        #If name is found then it will open file for password
                                        count=1
                                        for file in files:
                                                data_list=pickle.load(open(f'{path_dept}\{file}',"rb"))
                                                print(data_list)
                                                my_dept.insert(parent='',index='end',iid=count,text="",values=(count,data_list[0],data_list[2],data_list[1]))
                                                count+=1

                        student_info(),employee_info()
                        course_info(),dep_info()


                #----------------------------------- SIDE MENU-----------------------------------------------------------


                home_=Button(sideframe,text="Home",font=("FZYaoTi"),fg=label_fg,bg=frame_bg,relief="flat",command=home)
                home_.place(x=26,y=50,height=60,width=70)

                manage=Button(sideframe,text="Manage",font=("FZYaoTi"),fg=label_fg,bg=frame_bg,relief="flat",command=manage_func)
                manage.place(x=26,y=150,height=60,width=70)

                view=Button(sideframe,text="View",font=("FZYaoTi"),fg=label_fg,bg=frame_bg,relief="flat",command=view)
                view.place(x=26,y=250,height=60,width=70)


                def setting():
                    def theme_st():
                        new=Frame(dispframe,)

                        for widgets in dispframe.winfo_children():
                            widgets.destroy()

                            L=Label(dispframe,text="T H E M E",fg=label_fg,bg=frame_bg1)
                            L.place(x=10,y=10)
                            
                            def theme(event):
                                m=clicked.get()

                                if m=="Red Theme":
                                    e=main1(master,username="skhare12339@gmail.com",frame_bg="#4F0E0E",label_fg="#FFDADA",frame_bg1="#BB8760")
                                    
                                elif m=="Blue Theme":
                                    e=main1(master,username="skhare12339@gmail.com",frame_bg="#334257",label_fg="#EEEEEE",frame_bg1="#476072")

                                elif m=="Green Theme":
                                    e=main1(master,username="skhare12339@gmail.com",frame_bg="#081c15",label_fg="#52b788",frame_bg1="#1b4332")
                                
                                else:
                                    e=main1(master,username="skhare12339@gmail.com",frame_bg="#161616",label_fg="white",frame_bg1="#222222")
                                setting()

                            colour_modes=["Red Theme","Black Theme","Blue Theme","Green Theme"]
                            clicked=StringVar()
                            clicked.set("Choose Theme")
                            drop=OptionMenu(dispframe,clicked,*colour_modes,command=theme)
                            drop.config(bg=frame_bg,fg=label_fg,relief="flat",borderwidth=0)
                            drop["highlightthickness"]=0
                            
                            drop.place(x=90,y=10)    
                            
                           # L_button=Button(dispframe,text="Change theme",fg=label_fg,bg=frame_bg1,command=theme,relief="flat")
                           # L_button.place(x=70,y=10)
                        #e=main1(root,username="skhare12339@gmail.com",frame_bg="white",label_fg="black",frame_bg1="#C89B3B")
                    theme_st()
                
                settings=Button(sideframe,text="Settings",font=("FZYaoTi"),fg=label_fg,bg=frame_bg,relief="flat",command=setting)
                settings.place(x=26,y=350,height=60,width=70)
                


                def exit():
                        master.destroy()
                exit=Button(sideframe,text="Exit",font=("FZYaoTi"),fg=label_fg,bg=frame_bg,relief="flat",command=exit)
                exit.place(x=26,y=450,height=60,width=70)
                home()
                



#e=main1(root,username="skhare12339@gmail.com",frame_bg="#161616",label_fg="white",frame_bg1="#222222")
##root.mainloop()











